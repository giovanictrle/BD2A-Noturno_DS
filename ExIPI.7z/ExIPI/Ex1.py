import os

#Cria o arquivo no diretório 
cwd = os.path.abspath('Ex1_IP.txt') 
arq = open(cwd,'w')

#Escrevendo no arquivo
#\n pular linha
texto = []

texto.append('200.135.80.9\n')
texto.append('192.168.1.1\n')
texto.append('8.35.67.74\n')
texto.append('257.32.4.5\n')
texto.append('85.345.1.2\n')
texto.append('1.2.3.4\n')
texto.append('9.8.234.5\n')
texto.append('192.168.0.256\n')
arq.writelines(texto)
arq.close()
