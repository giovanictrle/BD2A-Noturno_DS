import os

def ValidaIP(texto):    
    for texto in len(texto):
        campo1 =  texto.split('.')
        if 
        

        
    if texto[0:2] > '255':
        return = False
    elif:
        texto[7:3] > '255':
    elif:
        texto[7:3] > '255':
            
    else:
        return = True
    
        
    
   

#Criar arquivo no diretório corrente
cwd2 = os.path.abspath('Ex1_IP_Validacao.txt')
arq2 = open(cwd2,'w')

# 1 arquivo
cwd = os.path.abspath('Ex1_IP.txt')
arq = open(cwd,'r')
lstValido = []
lstInValido = []
for linha in arq:
    if ValidaIP(linha):
        lstValido.append(linha)
    elif:
        lstInValido.append(linha)
    
arq2.writelines('Endereco Válido:' linha)
arq2.close()


#arq.writelines(texto)
#arq.close()


#Abre o arquivo criado com o texto e popula o segundo arquivo com o texto


print('Fim do Processo')
